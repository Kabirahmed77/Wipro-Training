function getUser() {
    fetch("https://randomuser.me/api/")
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            var user = data.results[0];
            var output = `
                
                Name: ${user.name.first} ${user.name.last} <br>
                Email: ${user.email}
            `;
            document.getElementById("result").innerHTML = output;
        })
        .catch(function() {
            document.getElementById("result").innerHTML = "Error loading user";
        });

}