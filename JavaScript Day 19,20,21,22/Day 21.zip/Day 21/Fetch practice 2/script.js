function getUser() {
    fetch("https://randomuser.me/api/")
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            var user = data.results[0];
            var output = `
                <img src="${user.picture.large}" width="100"><br><br>
                Name: ${user.name.first} ${user.name.last} <br>
                Email: ${user.email}
            `;
            document.getElementById("result").innerHTML = output;
        })
        .catch(function() {
            document.getElementById("result").innerHTML = "Error loading user";
        });
}