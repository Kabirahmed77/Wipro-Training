﻿using BCrypt.Net;
using System;
using System.IO; 
using System.Security.Cryptography;
using System.Text;
namespace WiproSecureApp
{
    public class SecurityService
    {
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("32-Character-Secret-Key-12345678");
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("16-Character-IV-");

        public string HashPassword(string password) => BCrypt.Net.BCrypt.HashPassword(password);

        public bool VerifyPassword(string password, string hash) => BCrypt.Net.BCrypt.Verify(password, hash);

        public string Encrypt(string plainText)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    using (var sw = new StreamWriter(cs))
                    {
                        sw.Write(plainText);
                    }
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }
    }
}