﻿using System.IO;
using Serilog;
using System;
using System.Collections.Generic;
namespace WiproSecureApp
{

    public class UserManager
    {
        private readonly List<User> _users = new List<User>();
        private readonly SecurityService _security = new SecurityService();

        public UserManager()
        {
            
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("logs/application_audit.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }   

        public void Register(string username, string password, string email)
        {
            
            try
            {
                var newUser = new User
                {
                    Username = username,
                    PasswordHash = _security.HashPassword(password), 
                    EncryptedEmail = _security.Encrypt(email)        
                };

                _users.Add(newUser);

                
                Log.Information("User {Username} registered successfully at {Time}", username, DateTime.Now);
            }
            catch (Exception ex)
            {
                
                Log.Error(ex, "An error occurred while registering user {Username}", username);
            }   
        }
    }
}