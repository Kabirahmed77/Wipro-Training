﻿using Xunit;
using WiproSecureApp;

namespace WiproSecureApp.Tests;

public class SecurityTests
{
    private readonly SecurityService _security = new SecurityService();

    [Fact]
    public void Hashing_ShouldMatchForCorrectPassword()
    {
        
        string password = "WiproPassword123";
        string hash = _security.HashPassword(password);

        
        bool isValid = _security.VerifyPassword(password, hash);

        
        Assert.True(isValid);
    }

    [Fact]
    public void Encryption_ShouldBeReversible()
    {
        
        string originalEmail = "test@wipro.com";
        string encrypted = _security.Encrypt(originalEmail);
        Assert.NotEqual(originalEmail, encrypted); 
    }
}