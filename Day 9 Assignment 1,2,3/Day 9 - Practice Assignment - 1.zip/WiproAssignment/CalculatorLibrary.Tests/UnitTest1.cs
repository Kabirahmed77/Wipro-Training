﻿using NUnit.Framework;
using CalculatorLibrary; 

namespace CalculatorLibrary.Tests
{
    [TestFixture]
    public class CalculatorTests
    {
        [Test]
        public void Test_Addition()
        {
            
            Calculator calc = new Calculator();
            double a = 10;
            double b = 20;

   
            double result = calc.Add(a, b);

           
            Assert.That(result, Is.EqualTo(30));
        }

        [Test]
        public void Test_DivisionByZero()
        {
            Calculator calc = new Calculator();

           
            Assert.Throws<DivideByZeroException>(() => calc.Divide(10, 0));
        }

        [Test]
        public void Test_MultiplyByZero()
        {
            Calculator calc = new Calculator();
            Assert.That(calc.Multiply(5, 0), Is.EqualTo(0));
        }

        [Test]
        public void Test_Subtraction()
        {
            
            Calculator calc = new Calculator();   
            double a = 50;
            double b = 20;

            double result = calc.Subtract(a, b);

            Assert.That(result, Is.EqualTo(30));
        }
    }
}