﻿namespace RazorPagesApp.Models
{
    public class InventoryItem
    {
        public string Name { get; set; }
    }
}
