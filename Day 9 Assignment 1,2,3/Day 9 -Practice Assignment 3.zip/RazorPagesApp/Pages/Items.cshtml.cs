using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPagesApp.Models; 

namespace RazorPagesApp.Pages
{
    public class ItemsModel : PageModel
    {
        
        public static List<InventoryItem> Inventory = new List<InventoryItem>
        {
            new InventoryItem { Name = "Laptop" },
            new InventoryItem { Name = "Mouse" }
        };

        
        [BindProperty]
        public string NewItemName { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrEmpty(NewItemName))
            {
                Inventory.Add(new InventoryItem { Name = NewItemName });
            }
            return RedirectToPage(); 
        }
    }
}
