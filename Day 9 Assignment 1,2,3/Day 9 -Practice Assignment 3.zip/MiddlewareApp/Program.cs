var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();


app.Use(async (context, next) =>
{
    Console.WriteLine($"[LOG] Request: {context.Request.Method} {context.Request.Path}");
    await next();
    Console.WriteLine($"[LOG] Response Code: {context.Response.StatusCode}");
});

app.UseHttpsRedirection();
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("Content-Security-Policy", "default-src 'self';");
    await next();
});


app.UseStaticFiles();

app.Run();