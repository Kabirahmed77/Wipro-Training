﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit

namespace LibraryManagement.Tests
{
    [TestFixture]
    public class LibrarySystemTests
    {
        private Library _library = null!;

        [SetUp]
        public void Setup()
        {
            _library = new Library();
        }


        [Test]
        public void AddBook_ShouldAddBookSuccessfully()
        {
            var book = new Book("The Great Gatsby", "F. Scott Fitzgerald", "12345");

            _library.AddBook(book);

            Assert.That(_library.Books.Count, Is.EqualTo(1));
            Assert.That(_library.Books.First().Title, Is.EqualTo("The Great Gatsby"));
        }


        [Test]
        public void RegisterBorrower_ShouldRegisterSuccessfully()
        {
            var borrower = new Borrower("John", "C001");

            _library.RegisterBorrower(borrower);

            Assert.That(_library.Borrowers.Count, Is.EqualTo(1));
            Assert.That(_library.Borrowers.First().Name, Is.EqualTo("John"));
        }


        [Test]
        public void BorrowBook_ShouldMarkBookAsBorrowed_AndAssociateWithBorrower()
        {
            var book = new Book("1984", "George Orwell", "111");
            var borrower = new Borrower("Alice", "C002");

            _library.AddBook(book);
            _library.RegisterBorrower(borrower);

            _library.BorrowBook("111", "C002");

            Assert.That(book.IsBorrowed, Is.True);
            Assert.That(borrower.BorrowedBooks, Contains.Item(book));
        }


        [Test]
        public void ReturnBook_ShouldMarkBookAsAvailable_AndRemoveFromBorrower()
        {
            var book = new Book("Harry Potter", "J.K. Rowling", "222");
            var borrower = new Borrower("Bob", "C003");

            _library.AddBook(book);
            _library.RegisterBorrower(borrower);
            _library.BorrowBook("222", "C003");

            _library.ReturnBook("222", "C003");

            Assert.That(book.IsBorrowed, Is.False);
            Assert.That(borrower.BorrowedBooks, Does.Not.Contain(book));
        }


        [Test]
        public void ViewBooksAndBorrowers_ShouldReturnCorrectLists()
        {
            var book = new Book("Clean Code", "Robert C. Martin", "333");
            var borrower = new Borrower("David", "C004");

            _library.AddBook(book);
            _library.RegisterBorrower(borrower);

            var books = _library.ViewBooks();
            var borrowers = _library.ViewBorrowers();

            Assert.That(books.Count, Is.EqualTo(1));
            Assert.That(borrowers.Count, Is.EqualTo(1));
        }
    }
}
